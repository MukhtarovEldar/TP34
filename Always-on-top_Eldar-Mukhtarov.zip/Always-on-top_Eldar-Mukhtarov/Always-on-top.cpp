#include <iostream>
#include <windows.h>

int main() {
    const wchar_t* filename = L"name.txt - Notepad";

    bool flagSuccessful = false, flagFailed = false;
    while (true) {
        HWND hwnd = FindWindowW(NULL, filename);
        if (hwnd) {
            SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
            if (IsIconic(hwnd)) {
                ShowWindow(hwnd, SW_RESTORE);
            }
            if (!flagSuccessful) {
                std::wcout << L"Successful." << std::endl;
                flagSuccessful = true;
                flagFailed = false;
            }
        } else {
            if (!flagFailed) {
                std::wcout << L"File not found." << std::endl;
                flagFailed = true;
                flagSuccessful = false;
            }
        }
        Sleep(1000);
    }
    return 0;
}